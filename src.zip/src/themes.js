const themes = {
    dark: {
        backgroundColor: "#36393f", // Discord dark background
        textColor: "#ffffff", // White text
        buttonColor: "#7289da", // Discord button color
        buttonHoverColor: "#5b6eae", // Button hover color
        messageBackground: "#2f3136", // Message background
        messageTextColor: "#ffffff", // Message text color
        clearButtonColor: "#dc3545", // Clear chat button color
        clearButtonHoverColor: "#c82333", // Clear chat button hover color
    },
    light: {
        backgroundColor: "#ffffff", // Light background
        textColor: "#333333", // Dark text
        buttonColor: "#007bff", // Bootstrap button color
        buttonHoverColor: "#0056b3", // Button hover color
        messageBackground: "#f1f1f1", // Message background
        messageTextColor: "#333333", // Message text color
        clearButtonColor: "#dc3545", // Clear chat button color
        clearButtonHoverColor: "#c82333", // Clear chat button hover color
    },
};

export default themes;

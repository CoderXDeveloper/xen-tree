import React, { useState } from "react";
import { db, storage } from "./firebase"; // Make sure to import storage
import { doc, setDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

const ProfileSetup = ({ user }) => {
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [profilePic, setProfilePic] = useState(null); // State for profile picture
  const [loading, setLoading] = useState(false); // State for loading

  const handleProfileSetup = async (e) => {
    e.preventDefault();
    setLoading(true); // Set loading state to true

    let photoURL = user.photoURL; // Default to existing photoURL

    try {
      // If a new profile picture is selected, upload it
      if (profilePic) {
        const storageRef = ref(storage, `profilePictures/${user.uid}`);
        await uploadBytes(storageRef, profilePic); // Upload the image
        photoURL = await getDownloadURL(storageRef); // Get the download URL
      }

      // Save user profile data to Firestore
      await setDoc(doc(db, "users", user.uid), {
        displayName,
        bio,
        photoURL,
      });

      alert("Profile updated!"); // Notify user
    } catch (error) {
      console.error("Error updating profile: ", error);
      alert("Failed to save profile. Please try again."); // Notify user of error
    } finally {
      setLoading(false); // Set loading state to false after operation
    }
  };

  return (
    <div className="profile-setup">
      <h2>Profile Setup</h2>
      <form onSubmit={handleProfileSetup} className="profile-form">
        <input
          type="text"
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          placeholder="Display Name"
          required
          className="profile-input"
        />
        <textarea
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          placeholder="Bio"
          required
          className="profile-bio"
        />
        <input
          type="file"
          accept="image/*"
          onChange={(e) => setProfilePic(e.target.files[0])}
          className="profile-pic-input"
        />
        <button type="submit" className="save-button" disabled={loading}>
          {loading ? "Saving..." : "Save Profile"}
        </button>
      </form>
    </div>
  );
};

export default ProfileSetup;

// Import necessary functions from Firebase SDK
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth"; // Import Google Auth Provider
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage"; // Import Firebase Storage
import { getAnalytics } from "firebase/analytics"; // Optional: Only if you need analytics

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAhnPdP4-0dKIVm8RvfhG9KGSqOVXcqgvk",
  authDomain: "xen-tree.firebaseapp.com",
  projectId: "xen-tree",
  storageBucket: "xen-tree.appspot.com",
  messagingSenderId: "213439557818",
  appId: "1:213439557818:web:1bd285b611c3dbef78d283",
  measurementId: "G-TPN5SMLMEF" // Optional: Only if you need analytics
};

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Optional: Initialize Firebase Analytics
const analytics = getAnalytics(app);

// Initialize Firebase Authentication
const auth = getAuth(app);

// Initialize Firestore Database
const db = getFirestore(app);

// Initialize Firebase Storage
const storage = getStorage(app);

// Export the Firebase services for use in other parts of the app
export { auth, db, storage, GoogleAuthProvider };

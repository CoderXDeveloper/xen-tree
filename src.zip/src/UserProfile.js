import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import { doc, getDoc } from "firebase/firestore";

const UserProfile = ({ userId }) => {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      const docRef = doc(db, "users", userId);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        setProfile(docSnap.data());
      } else {
        console.log("No such document!");
      }
    };

    fetchProfile();
  }, [userId]);

  return (
    <div className="user-profile">
      {profile ? (
        <>
          <h2>{profile.displayName}'s Profile</h2>
          <p>Bio: {profile.bio}</p>
          <img src={profile.photoURL} alt={profile.displayName} className="user-photo" />
        </>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default UserProfile;

// src/Login.js
import React from "react";
import { auth, GoogleAuthProvider } from "./firebase"; // Import Firebase services
import { signInWithPopup } from "firebase/auth"; // Import signInWithPopup

const Login = () => {
  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider(); // Create a new Google Auth Provider

    try {
      await signInWithPopup(auth, provider); // Sign in with Google
    } catch (error) {
      console.error("Error during Google login:", error);
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <button onClick={handleGoogleLogin}>Sign in with Google</button>
    </div>
  );
};

export default Login;

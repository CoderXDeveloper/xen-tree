import React, { useState, useEffect } from "react";
import { db } from "./firebase";
import { collection, addDoc, query, onSnapshot, orderBy, doc, setDoc } from "firebase/firestore"; // Added setDoc for user management
import "./DirectMessages.css"; // Import your CSS file for styling

const DirectMessages = ({ user }) => {
  const [users, setUsers] = useState([]); // List of users logged into the app
  const [selectedUser, setSelectedUser] = useState(null); // Selected user for messaging
  const [messages, setMessages] = useState([]); // Messages between the current user and the selected user
  const [newMessage, setNewMessage] = useState(""); // New message input state

  // Fetch all logged-in users except the current user
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "users"), (snapshot) => {
      const usersData = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })).filter(u => u.id !== user.uid); // Exclude the current user
      setUsers(usersData);
    });

    return () => unsubscribe();
  }, [user]);

  // Fetch direct messages between the current user and the selected user
  useEffect(() => {
    if (selectedUser) {
      const chatId = user.uid > selectedUser.id ? `${user.uid}_${selectedUser.id}` : `${selectedUser.id}_${user.uid}`; // Unique chat ID based on UIDs
      const q = query(collection(db, `directMessages/${chatId}/messages`), orderBy("createdAt"));

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const messagesData = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setMessages(messagesData);
      });

      return () => unsubscribe();
    }
  }, [selectedUser, user]);

  // Handle sending a new message
  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (newMessage.trim() && selectedUser) {
      const chatId = user.uid > selectedUser.id ? `${user.uid}_${selectedUser.id}` : `${selectedUser.id}_${user.uid}`;
      try {
        await addDoc(collection(db, `directMessages/${chatId}/messages`), {
          text: newMessage,
          createdAt: new Date(),
          senderId: user.uid,
        });
        setNewMessage("");
      } catch (error) {
        console.error("Error sending direct message: ", error);
      }
    }
  };

  // Create a document in the "users" collection when the user logs in (if it doesn't exist already)
  useEffect(() => {
    const addUserToDB = async () => {
      if (user) {
        try {
          await setDoc(doc(db, "users", user.uid), {
            displayName: user.displayName,
            email: user.email,
            photoURL: user.photoURL,
          }, { merge: true }); // Merge in case the user already exists
        } catch (error) {
          console.error("Error adding user to Firestore: ", error);
        }
      }
    };
    addUserToDB();
  }, [user]);

  return (
    <div className="direct-messages">
      <h2>Direct Messages</h2>
      {/* List of users */}
      <div className="user-list">
        {users.map((u) => (
          <div
            key={u.id}
            className={`user-item ${selectedUser && selectedUser.id === u.id ? "selected" : ""}`}
            onClick={() => setSelectedUser(u)}
          >
            <img src={u.photoURL} alt={u.displayName} className="user-avatar" />
            {u.displayName}
          </div>
        ))}
      </div>

      {/* Chat area */}
      {selectedUser && (
        <div className="chat">
          <h3>Chatting with {selectedUser.displayName}</h3>
          <div className="messages">
            {messages.map((message) => (
              <div key={message.id} className={`message ${message.senderId === user.uid ? "sent" : "received"}`}>
                <strong>{message.senderId === user.uid ? "You" : selectedUser.displayName}:</strong> {message.text}
              </div>
            ))}
          </div>
          {/* Message input form */}
          <form onSubmit={handleSendMessage} className="message-form">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="message-input"
            />
            <button type="submit" className="send-button">Send</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default DirectMessages;

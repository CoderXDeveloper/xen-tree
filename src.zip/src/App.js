// src/App.js
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { auth } from "./firebase";
import { onAuthStateChanged } from "firebase/auth";
import Chat from "./Chat";
import ProfileSetup from "./ProfileSetup";
import Sidebar from "./Sidebar";
import DirectMessages from "./DirectMessages";
import Home from "./Home"; // Make sure this is imported correctly
import "./styles.css"; 

function App() {
  const [user, setUser] = useState(null);
  const [theme, setTheme] = useState("dark"); // Default theme

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });

    return () => unsubscribe();
  }, []);

  // Toggle theme function
  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === "dark" ? "light" : "dark"));
  };

  return (
    <Router>
      <div className={`app ${theme}`}> {/* Add theme class to the main app */}
        <Sidebar user={user} theme={theme} toggleTheme={toggleTheme} />
        <div className="main-content">
          <Routes>
            <Route path="/" element={user ? <Chat user={user} theme={theme} /> : <Home />} />
            <Route path="/profile" element={<ProfileSetup user={user} />} />
            <Route path="/direct-messages" element={<DirectMessages user={user} />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;

// src/Home.js
import React from "react";
import { signInWithPopup } from "firebase/auth"; 
import { auth, GoogleAuthProvider } from "./firebase"; 
import "./styles.css"; 

const Home = () => {
  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, new GoogleAuthProvider()); 
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  return (
    <div className="home">
      <h1>Welcome to the Xen Tree</h1>
      <p>Please log in to continue.</p>
      <button onClick={handleLogin} className="login-button">Login with Google</button>
    </div>
  );
};

export default Home;

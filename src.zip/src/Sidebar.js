// src/Sidebar.js
import React from "react";
import { Link } from "react-router-dom"; 
import { signOut } from "firebase/auth"; 
import { auth } from "./firebase"; 
import "./styles.css"; 

const Sidebar = ({ user }) => {
  const handleLogout = async () => {
    try {
      await signOut(auth); 
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <div className="sidebar">
      <div className="profile">
        {user?.photoURL && <img src={user.photoURL} alt={user.displayName} />}
        <h3>{user?.displayName || "User"}</h3>
      </div>
      <nav>
        <ul>
          <li>
            <Link to="/">Chat</Link>
          </li>
          <li>
            <Link to="/profile">Profile Settings</Link>
          </li>
          <li>
            <Link to="/direct-messages">Direct Messages</Link>
          </li>
          <li>
            <button onClick={handleLogout} className="logout-button">Logout</button>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;

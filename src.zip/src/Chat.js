import React, { useState, useEffect, useRef } from "react";
import { db, storage } from "./firebase"; // Import Firebase Storage
import { collection, addDoc, onSnapshot, doc, getDoc, query, orderBy, writeBatch } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"; // Firebase Storage functions
import EmojiPicker from "emoji-picker-react"; // Emoji picker library
import themes from "./themes"; // Import themes
import "./Chat.css"; // Import your CSS file for styling

const Chat = ({ user }) => {
    const [message, setMessage] = useState("");
    const [messages, setMessages] = useState([]);
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);
    const [file, setFile] = useState(null); // For image uploads
    const fileInputRef = useRef(null);
    const [theme, setTheme] = useState("dark"); // Default theme

    // Fetch messages from Firestore with ordering
    useEffect(() => {
        const messagesRef = collection(db, "messages");
        const q = query(messagesRef, orderBy("timestamp"));

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const messagesData = snapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
            setMessages(messagesData);
        });

        return () => unsubscribe();
    }, []);

    // Send a message (text or image)
    const sendMessage = async (e) => {
        e.preventDefault();

        if (message.trim() === "" && !file) return;

        try {
            let imageUrl = "";
            if (file) {
                const storageRef = ref(storage, `images/${Date.now()}_${file.name}`);
                const snapshot = await uploadBytes(storageRef, file);
                imageUrl = await getDownloadURL(snapshot.ref);
            }

            await addDoc(collection(db, "messages"), {
                uid: user.uid,
                text: message,
                imageUrl: imageUrl, // Save image URL if any
                timestamp: new Date(),
            });

            setMessage(""); // Clear input after sending
            setFile(null); // Clear file input
        } catch (error) {
            console.error("Failed to send message:", error);
            alert("Failed to send message. Please try again.");
        }
    };

    // Handle emoji selection
    const onEmojiClick = (event, emojiObject) => {
        setMessage((prevMessage) => prevMessage + emojiObject.emoji);
        setShowEmojiPicker(false); // Hide picker after selecting
    };

    // Handle image upload
    const handleImageUpload = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile) {
            setFile(selectedFile);
        }
    };

    // Handle pasting images
    const handlePaste = (e) => {
        const items = e.clipboardData.items;
        for (let item of items) {
            if (item.type.startsWith("image/")) {
                const blob = item.getAsFile();
                setFile(blob);
                break;
            }
        }
    };

    // Clear chat function
    const clearChat = async () => {
        const batch = writeBatch(db);

        messages.forEach((msg) => {
            const msgRef = doc(db, "messages", msg.id);
            batch.delete(msgRef);
        });

        try {
            await batch.commit();
            setMessages([]);
        } catch (error) {
            console.error("Failed to clear chat:", error);
            alert("Failed to clear chat. Please try again.");
        }
    };

    // Toggle theme
    const toggleTheme = () => {
        setTheme((prevTheme) => (prevTheme === "dark" ? "light" : "dark"));
    };

    return (
        <div className="chat" style={{ backgroundColor: themes[theme].backgroundColor, color: themes[theme].textColor }}>
            <button onClick={toggleTheme} style={{ backgroundColor: themes[theme].buttonColor, color: themes[theme].textColor }}>
                Switch to {theme === "dark" ? "Light" : "Dark"} Theme
            </button>
            <div className="messages">
                {messages.map((msg) => (
                    <Message key={msg.id} message={msg} theme={theme} />
                ))}
            </div>
            <form onSubmit={sendMessage} className="chat-form" onPaste={handlePaste}>
                <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="chat-input"
                    rows={3} // Multi-line support
                    style={{ backgroundColor: themes[theme].messageBackground, color: themes[theme].messageTextColor }}
                />
                <button type="button" onClick={() => setShowEmojiPicker(!showEmojiPicker)} className="emoji-button">
                    😀
                </button>
                {showEmojiPicker && <EmojiPicker onEmojiClick={onEmojiClick} />}
                
                <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="image-input"
                    style={{ display: "none" }}
                />
                <button type="button" onClick={() => fileInputRef.current.click()} className="upload-button">
                    Upload Image
                </button>
                
                <button type="submit" className="chat-send-button" style={{ backgroundColor: themes[theme].buttonColor, color: themes[theme].textColor }}>
                    Send
                </button>
            </form>
            <button onClick={clearChat} className="chat-clear-button" style={{ backgroundColor: themes[theme].clearButtonColor, color: themes[theme].textColor }}>
                Clear Chat
            </button>
        </div>
    );
};

// Component to render each message
const Message = ({ message, theme }) => {
    const [userData, setUserData] = useState(null);

    useEffect(() => {
        const fetchUserData = async () => {
            if (!message.uid) {
                console.error("Message UID is undefined");
                return;
            }

            try {
                const docRef = doc(db, "users", message.uid);
                const userDoc = await getDoc(docRef);
                if (userDoc.exists()) {
                    setUserData(userDoc.data());
                } else {
                    console.error("No such user document!");
                }
            } catch (error) {
                console.error("Error fetching user data:", error);
            }
        };

        fetchUserData();
    }, [message.uid]);

    return (
        <div className="message" style={{ backgroundColor: themes[theme].messageBackground, color: themes[theme].messageTextColor }}>
            {userData ? (
                <>
                    <img src={userData.photoURL} alt={userData.displayName} className="user-avatar" />
                    <strong>{userData.displayName}</strong>: {message.text}
                    {message.imageUrl && <img src={message.imageUrl} alt="Uploaded" className="message-image" />}
                </>
            ) : (
                <p>Loading...</p>
            )}
        </div>
    );
};

export default Chat;
